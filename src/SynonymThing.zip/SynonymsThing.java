import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class SynonymsThing {
    public static String getSynonyms(String word) {
        try {
            String urlString = "https://api.datamuse.com/words?rel_syn=" + word;
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            
            InputStream inputStream = conn.getInputStream();
            String response = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            inputStream.close();
            JSONArray jsonArray = new JSONArray(response);
            if (jsonArray.length() > 0) {
                return jsonArray.getJSONObject(0).getString("word");
            } else {
                return word;
            }
        } catch (Exception e) {
            return("it didn't work :(");
            
        }
    }

    public static void main(String[] args) {

	try{
	Scanner scanner = new Scanner(new File("Input.txt"));
        FileWriter writer = new FileWriter("Output.txt");
        ArrayList<String> newWords= new ArrayList<>();
        while (scanner.hasNextLine()) {
            String[] words = scanner.nextLine().split(" ");
            for (String word : words) {
		System.out.println(word);
		writer.write(getSynonyms(word));
		writer.write(getSynonyms(" "));
            }

        }
            writer.close();
    }
	catch(Exception e) {
		System.out.println("It didnt work");
}
}
}