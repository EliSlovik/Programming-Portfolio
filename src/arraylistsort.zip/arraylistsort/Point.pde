class Point{
  int x, y;
 public Point(int x, int y) {
    this.x = x;
    this.y = y;
 }
  int getY() {
     return y; 
  }
  void setX(int newX) {
     x = newX; 
  }
}
