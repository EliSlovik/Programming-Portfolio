ArrayList<Point> numbers = new ArrayList<Point>();
int i = 0;
int j = 0;

void setup() {
  size(600, 600);
  background(200);

  for (int k = 0; k < 20; k++) {
    numbers.add(new Point((30 * k) + 26, (int)random(26, 594)));
  }
}

void draw() {
  background(200);
  line(20, 580, 580, 580);
  line(20, 20, 20, 580);
  textSize(25);
  fill(0);
  text("X", 585, 589);
  text("Y", 15, 19);

  for (int k = 0; k < numbers.size(); k++) {
    ellipse(numbers.get(k).x, height - numbers.get(k).y, 5, 5);
    //draw lines from the point to the previous one.
    if (k > 0) {
      line(numbers.get(k).x, height - numbers.get(k).y, numbers.get(k - 1).x, height - numbers.get(k - 1).y);
    }
  }
  //i used an "if" instead of a standard "for" loop to iterate on frame at a time. It sorts once then draws, vs. a "for" loop, which sorts the entire thing and then draws.
  if (i < numbers.size() - 1) {
    if (j < numbers.size() - 1) {
      if (numbers.get(j).y > numbers.get(j + 1).y) {
        Point temp = numbers.get(j);
        numbers.set(j, numbers.get(j + 1));
        numbers.set(j + 1, temp);
        int tempX = numbers.get(j).x;
        numbers.get(j).setX(numbers.get(j+1).x);
        numbers.get(j+1).setX(tempX);
        delay(50);
      }
      j++;
    } else {
      j = 0;
      i++;
    }
  }
} //<>//
